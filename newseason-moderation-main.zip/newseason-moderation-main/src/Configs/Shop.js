module.exports = [
  { ID: 1, name: "Nitro Classic", detay: "1 Ay", tagliozel: true, coin: 80600 },
  { ID: 2, name: "Nitro Boostlu", detay: "1 Ay", tagliozel: true, coin: 125000 },

  { ID: 3, name: "Spotify Aylık", detay: "1 Ay", tagliozel: false, coin: 19200 },
  { ID: 4, name: "Spotify Yıllık", detay: "1 Yıl", tagliozel: false, coin: 66500 },

  { ID: 5, name: "Exxen Aylık", detay: "1 Ay", tagliozel: false, coin: 19500 },
  { ID: 6, name: "Exxen Yıllık", detay: "1 Yıl", tagliozel: false, coin: 78700 },

  { ID: 7, name: "Youtube Aylık", detay: "1 Ay", tagliozel: false, coin: 22400 },
  { ID: 8, name: "Youtube Yıllık", detay: "1 Yıl", tagliozel: false, coin: 66500 },

  { ID: 9, name: "Netflix", detay: "1 Ay", tagliozel: false, coin: 24500 },
];
