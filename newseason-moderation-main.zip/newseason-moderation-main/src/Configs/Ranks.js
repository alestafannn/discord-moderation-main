const Settings = require('./Settings');

module.exports = [
  { index: 0, id: "", puan: 0, hammers: ['', ''] },
  { index: 1, id: "", puan: 400, hammers: ['', ''] },
  { index: 2, id: "", puan: 500, hammers: ['', ''] },
  { index: 3, id: "", puan: 650, hammers: ['', ''] },
  { index: 4, id: "", puan: 850, hammers: ['', ''] },

  { index: 5, id: "", puan: 1250, hammers: ['', ''] },
  { index: 6, id: "", puan: 1700, hammers: ['', ''] },
  { index: 7, id: "", puan: 2150, hammers: ['', ''] },
  { index: 8, id: "", puan: 2500, hammers: ['', ''] },
  { index: 9, id: "", puan: 5000, hammers: ['', ''] },
  { index: 10, id: "", puan: 5250, hammers: ['', ''] },
  { index: 11, id: "", puan: 5750, hammers: ['', ''] },
  { index: 12, id: "", puan: 7000, hammers: ['', ''] },
  { index: 13, id: "", puan: 7500, hammers: ['', ''] },
  { index: 14, id: "", puan: 8000, hammers: ['', ''] },
  { index: 15, id: "", puan: 12000, hammers: ['', ''] },
  { index: 16, id: "", puan: 13000, hammers: ['', ''] },
];
