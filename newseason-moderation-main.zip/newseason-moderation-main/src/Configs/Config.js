module.exports = {
    Token: "",
    MongoDB: "",
    Owners: ['', ''],
    Prefix: [""],

    Status: ['Awoken ❤️ ibidi', 'ibidi ❤️ Awoken']
};
